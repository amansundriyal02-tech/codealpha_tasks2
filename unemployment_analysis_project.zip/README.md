# 📊 Internship Assignment - Task 2: Unemployment Analysis with Python

This project analyzes unemployment rate data to understand how unemployment trends have changed over time — especially during the COVID-19 pandemic.  
The analysis helps visualize regional patterns and trends that could inform future economic and social policies.

## 🧠 Project Objectives
- Analyze unemployment rate data using Python
- Perform data cleaning, exploration, and visualization
- Examine the impact of COVID-19 on unemployment
- Identify key patterns or seasonal trends
- Present data-driven insights for policy consideration

## 🧰 Technologies Used
- Python
- Pandas
- Matplotlib
- Seaborn

## 📁 Dataset
Download the dataset from the provided internship source and save it as:
```
unemployment_data.csv
```

## 🚀 How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/unemployment-analysis.git
   cd unemployment-analysis
   ```
2. Install dependencies:
   ```bash
   pip install pandas matplotlib seaborn
   ```
3. Run the analysis script:
   ```bash
   python unemployment_analysis.py
   ```

## 📈 Visual Insights
- Histogram: Distribution of unemployment rates
- Bar Plot: Average unemployment rate by region
- Line Chart: Unemployment trends over time
- COVID-19 Focus: Trends during the 2020 pandemic

## 💡 Insights
1. Unemployment rates spiked during COVID-19 (2020–2021).
2. Regional unemployment patterns vary widely.
3. Seasonal or cyclical variations may exist.
4. Insights can guide economic recovery and job creation policies.

## ✨ Author
**Aman Sundriyal**
Internship Project — Task 2: Unemployment Analysis with Python
