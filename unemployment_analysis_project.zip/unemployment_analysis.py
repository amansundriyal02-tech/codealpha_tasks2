# Internship Assignment - Task 2: Unemployment Analysis with Python
# Author: Aman Sundriyal
# Description: Analyze unemployment rate data to explore trends, visualize patterns,
# and understand the impact of COVID-19 on unemployment in different regions.

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
data = pd.read_csv("unemployment_data.csv")

# Display basic information
print("Dataset Preview:")
print(data.head())
print("\nDataset Info:")
print(data.info())

# Check for missing values
print("\nMissing Values:")
print(data.isnull().sum())

# Data Cleaning
data.dropna(inplace=True)

# Summary statistics
print("\nSummary Statistics:")
print(data.describe())

# Exploratory Data Analysis (EDA)
plt.figure(figsize=(10,6))
sns.histplot(data['Estimated Unemployment Rate (%)'], bins=20, kde=True)
plt.title("Distribution of Unemployment Rate (%)")
plt.xlabel("Unemployment Rate (%)")
plt.ylabel("Frequency")
plt.show()

# Average unemployment by region
plt.figure(figsize=(12,6))
region_data = data.groupby('Region')['Estimated Unemployment Rate (%)'].mean().sort_values(ascending=False)
sns.barplot(x=region_data.values, y=region_data.index, palette="coolwarm")
plt.title("Average Unemployment Rate by Region")
plt.xlabel("Average Unemployment Rate (%)")
plt.ylabel("Region")
plt.show()

# Time-series analysis
if 'Date' in data.columns:
    data['Date'] = pd.to_datetime(data['Date'])
    plt.figure(figsize=(12,6))
    sns.lineplot(x='Date', y='Estimated Unemployment Rate (%)', data=data)
    plt.title("Unemployment Rate Over Time")
    plt.xlabel("Date")
    plt.ylabel("Unemployment Rate (%)")
    plt.show()

# COVID-19 Impact Analysis (2020 onwards)
if 'Date' in data.columns:
    covid_period = data[data['Date'] >= '2020-01-01']
    plt.figure(figsize=(12,6))
    sns.lineplot(x='Date', y='Estimated Unemployment Rate (%)', data=covid_period, color='red')
    plt.title("Unemployment Trends During COVID-19 (2020 onwards)")
    plt.xlabel("Date")
    plt.ylabel("Unemployment Rate (%)")
    plt.show()

print("\nInsights:")
print("1️⃣ Unemployment rates increased significantly during the COVID-19 period (2020–2021).")
print("2️⃣ Regional differences are visible — some states or regions show consistently higher rates.")
print("3️⃣ Seasonal variation can be observed depending on region and industry patterns.")
print("4️⃣ Data-driven insights can help policymakers focus on employment support programs.")
